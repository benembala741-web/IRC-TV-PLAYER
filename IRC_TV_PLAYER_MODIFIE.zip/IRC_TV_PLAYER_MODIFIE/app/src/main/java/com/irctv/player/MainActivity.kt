package com.irctv.player

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

private val backgroundColor = Color.rgb(10, 15, 28)
private val cardColor = Color.rgb(25, 33, 52)
private val white = Color.WHITE
private val secondaryText = Color.rgb(170, 185, 210)

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    showHome()
}

private fun showHome() {

    val root = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(backgroundColor)
        setPadding(24, 30, 24, 24)
    }

    val scrollView = ScrollView(this)

    val content = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
    }

    val title = TextView(this).apply {
        text = "IRC TV PLAYER"
        textSize = 30f
        setTextColor(white)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
    }

    content.addView(title)

    val subtitle = TextView(this).apply {
        text = "Votre divertissement, partout."
        textSize = 16f
        setTextColor(secondaryText)
        gravity = Gravity.CENTER
        setPadding(0, 8, 0, 25)
    }

    content.addView(subtitle)

    val search = EditText(this).apply {
        hint = "🔎  Rechercher une chaîne..."
        textSize = 16f
        setTextColor(white)
        setHintTextColor(secondaryText)
        setSingleLine(true)
        setPadding(20, 15, 20, 15)
        setBackgroundColor(cardColor)
    }

    content.addView(search)

    val categoriesTitle = TextView(this).apply {
        text = "CATÉGORIES"
        textSize = 18f
        setTextColor(white)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 28, 0, 12)
    }

    content.addView(categoriesTitle)

    val categories = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
    }

    addCategoryButton(categories, "Toutes")
    addCategoryButton(categories, "Actualités")
    addCategoryButton(categories, "Sport")
    addCategoryButton(categories, "Musique")

    content.addView(categories)

    val channelsTitle = TextView(this).apply {
        text = "CHAÎNES TV"
        textSize = 20f
        setTextColor(white)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 28, 0, 15)
    }

    content.addView(channelsTitle)

    addChannel(content, "RTNC", "Actualités", "🇨🇩")
    addChannel(content, "TV5 Monde", "Actualités", "🌍")
    addChannel(content, "SPORT TV", "Sport", "⚽")
    addChannel(content, "MUSIC TV", "Musique", "🎵")
    addChannel(content, "IRC TV", "Divertissement", "📺")

    val info = TextView(this).apply {
        text = "Les chaînes affichées sont des chaînes de démonstration. Les vrais flux vidéo seront ajoutés ultérieurement."
        textSize = 13f
        setTextColor(secondaryText)
        setPadding(0, 25, 0, 20)
    }

    content.addView(info)

    scrollView.addView(content)

    root.addView(
        scrollView,
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        )
    )

    setContentView(root)
}

private fun addCategoryButton(
    container: LinearLayout,
    name: String
) {
    val button = Button(this).apply {
        text = name
        textSize = 12f
        setTextColor(white)

        setOnClickListener {
            Toast.makeText(
                this@MainActivity,
                "Catégorie : $name",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    container.addView(
        button,
        LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        )
    )
}

private fun addChannel(
    container: LinearLayout,
    name: String,
    category: String,
    icon: String
) {

    val card = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(cardColor)
        setPadding(18, 18, 18, 18)
    }

    val iconView = TextView(this).apply {
        text = icon
        textSize = 30f
        gravity = Gravity.CENTER
    }

    card.addView(
        iconView,
        LinearLayout.LayoutParams(60, 70)
    )

    val information = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(15, 0, 10, 0)
    }

    val channelName = TextView(this).apply {
        text = name
        textSize = 18f
        setTextColor(white)
        typeface = Typeface.DEFAULT_BOLD
    }

    val channelCategory = TextView(this).apply {
        text = category
        textSize = 13f
        setTextColor(secondaryText)
    }

    information.addView(channelName)
    information.addView(channelCategory)

    card.addView(
        information,
        LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        )
    )

    val playButton = Button(this).apply {
        text = "▶"
        textSize = 18f

        setOnClickListener {
            showPlayer(name)
        }
    }

    card.addView(
        playButton,
        LinearLayout.LayoutParams(
            60,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
    )

    val params = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    params.setMargins(0, 0, 0, 14)

    container.addView(card, params)
}

private fun showPlayer(channelName: String) {

    val layout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setBackgroundColor(Color.BLACK)
        setPadding(25, 25, 25, 25)
    }

    val title = TextView(this).apply {
        text = "IRC TV PLAYER"
        textSize = 26f
        setTextColor(white)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
    }

    layout.addView(title)

    val channel = TextView(this).apply {
        text = "\n$channelName\n\n▶ LECTEUR VIDÉO\n\nAucun flux vidéo n'est encore configuré."
        textSize = 20f
        setTextColor(white)
        gravity = Gravity.CENTER
        setPadding(20, 30, 20, 30)
    }

    layout.addView(
        channel,
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        )
    )

    val backButton = Button(this).apply {
        text = "← Retour aux chaînes"

        setOnClickListener {
            showHome()
        }
    }

    layout.addView(backButton)

    setContentView(layout)
}

}